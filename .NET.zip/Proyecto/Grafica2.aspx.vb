﻿
Partial Class Grafica2
    Inherits System.Web.UI.Page

End Class
