﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class logeo
    Inherits System.Web.UI.Page

    Public Sub habilitar()
        txtusuario0.Enabled = True
        txtcontraseña0.Enabled = True
        txtre_contr.Enabled = True
        txtnombre.Enabled = True
        txtapellidos.Enabled = True
        dpdlsexo.Enabled = True
        txtemail.Enabled = True
        btnregistrar.Enabled = True
    End Sub

    Public Sub deshabilitar()
        txtusuario0.Enabled = False
        txtcontraseña0.Enabled = False
        txtre_contr.Enabled = False
        txtnombre.Enabled = False
        txtapellidos.Enabled = False
        dpdlsexo.Enabled = False
        txtemail.Enabled = False
        btnregistrar.Enabled = False
    End Sub

    Public Sub limpiar()
        txtusuario0.Text = ""
        txtcontraseña0.Text = ""
        txtre_contr.Text = ""
        txtnombre.Text = ""
        txtapellidos.Text = ""
        txtemail.Text = ""
    End Sub

    Protected Sub btnaceptar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnaceptar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim comando As New SqlCommand("sesion", conectar)
            Dim reader As SqlDataReader
            comando.CommandType = 4
            With comando.Parameters
                .AddWithValue("@usuario", txtusuario.Text.ToUpper)
                .AddWithValue("@contraseña", txtcontraseña.Text.ToUpper)
            End With
            reader = comando.ExecuteReader
            If reader.HasRows = True Then
                MsgBox("Bienvenido al sistema ...", MsgBoxStyle.Information, "Mensaje")
                Response.Redirect("principal.aspx")

                lbl1.Text = ""
            Else
                MsgBox("Usuario o contraseña incorrectos", vbExclamation, "Aviso")
            End If
            conectar.Close()

        Catch ex As Exception
            lbl1.Text = "Usuario o contraseña incorrectos"
        End Try

    End Sub

    Protected Sub btnregistrar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnregistrar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim insertar As New String("Insert into registro values('" & txtusuario0.Text & "','" & txtcontraseña0.Text & "','" & txtnombre.Text & "','" & txtapellidos.Text & "','" & dpdlsexo.Text & "','" & txtemail.Text & "')")
            Dim comando As New SqlCommand(insertar, conectar)
            If txtusuario0.Text <> "" And txtcontraseña0.Text = txtre_contr.Text And txtnombre.Text <> "" And txtapellidos.Text <> "" And txtemail.Text <> "" Then
                comando.ExecuteNonQuery()
                MsgBox("Usuario registrado correctamente", vbInformation, "Mensaje")
                lbl1.Text = ""
                deshabilitar()
                conectar.Close()
            Else
                MsgBox("Complete el espacio emblanco", vbInformation, "Mensaje")
            End If

        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnok_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnok.Click
        Dim usuario As String
        Dim password As String
        usuario = txtid_admin.Text
        password = txtpass_admin.Text
        If usuario = "miproyectofinal" And password = "alpormayor" Then
            MsgBox("La cuenta es correcta", vbInformation, "Mensaje")
            habilitar()
            txtid_admin.Text = ""
            txtpass_admin.Text = ""
            limpiar()
        Else
            MsgBox("La cuenta es incorrecta", vbInformation, "Aviso")
            deshabilitar()
            txtid_admin.Text = ""
            txtpass_admin.Text = ""
            limpiar()
        End If
    End Sub
End Class
