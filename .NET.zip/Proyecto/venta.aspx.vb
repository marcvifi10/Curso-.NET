﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class venta
    Inherits System.Web.UI.Page

    Protected Sub btnbuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnbuscar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim buscar As New String("select * from producto where codigo_prod='" & txtcod_prod.Text.ToUpper & "'")
            Dim comando As New SqlCommand(buscar, conectar)
            Dim reader As SqlDataReader
            reader = comando.ExecuteReader
            While reader.Read
                txtmarca.Text = reader("marca")
                txtdescripcion.Text = reader("descripcion")
                txtstock.Text = reader("stock_cajas")
                MsgBox("Busqueda satisfactoria", vbInformation, "Mensaje")
                lbl1.Text = ""
            End While
            reader.Close()
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnvender_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnvender.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim insertar As New String("Insert into venta (cliente,domicilio,codigo_prod,vendedor,cantidad_vend) values('" & txtcliente.Text.ToUpper & "','" & txtdomicilio.Text.ToUpper & "','" & txtcod_prod.Text.ToUpper & "','" & txtvendedor.Text.ToUpper & "','" & txtcant_vendidas.Text.ToUpper & "')")
            Dim modificar As New String("update producto set stock_cajas = stock_cajas - '" & txtcant_vendidas.Text.ToUpper & "' where codigo_prod='" & txtcod_prod.Text.ToUpper & "'")
            Dim comando As New SqlCommand(insertar, conectar)
            Dim comando2 As New SqlCommand(modificar, conectar)
            comando.ExecuteNonQuery()
            comando2.ExecuteNonQuery()
            lbl2.Text = "Producto vendido satisfactoriamente"
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub
End Class
