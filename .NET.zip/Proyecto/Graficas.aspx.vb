﻿
Partial Class Graficas
    Inherits System.Web.UI.Page

End Class
