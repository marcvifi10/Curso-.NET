﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class modificar_venta
    Inherits System.Web.UI.Page

    Public Sub deshabilitar()
        txtcodigo.Enabled = False
        txtcliente.Enabled = False
        txtdomicilio.Enabled = False
        txtcod_prod.Enabled = False
        txtvendedor.Enabled = False
        txtfechavendida.Enabled = False
    End Sub

    Public Sub habilitar()
        txtcodigo.Enabled = True
        txtcliente.Enabled = True
        txtdomicilio.Enabled = True
        txtcod_prod.Enabled = True
        txtvendedor.Enabled = True
        txtfechavendida.Enabled = True
    End Sub

    Protected Sub btnbuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnbuscar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim buscar As New String("select * from venta where id_venta='" & txtcodigo.Text.ToUpper & "'")
            Dim comando As New SqlCommand(buscar, conectar)
            Dim reader As SqlDataReader
            reader = comando.ExecuteReader
            While reader.Read
                txtcodigo.Text = reader("id_venta")
                txtcliente.Text = reader("cliente")
                txtdomicilio.Text = reader("domicilio")
                txtcod_prod.Text = reader("codigo_prod")
                txtvendedor.Text = reader("vendedor")
                txtcantidad.Text = reader("cantidad_vend")
                txtfechavendida.Text = reader("fecha_venta")
                habilitar()
                MsgBox("Busqueda satisfactoria", vbInformation, "Mensaje")
                lbl1.Text = ""
            End While
            reader.Close()
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnmodificar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnmodificar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim modificar As New String("update venta set cliente='" & txtcliente.Text.ToUpper & "',domicilio='" & txtdomicilio.Text.ToUpper & "',codigo_prod='" & txtcod_prod.Text.ToUpper & "',vendedor='" & txtvendedor.Text.ToUpper & "',cantidad_vend=cantidad_vend - '" & txtdevuelto.Text.ToUpper & "',fecha_venta='" & txtfechavendida.Text.ToUpper & "' where id_venta='" & txtcodigo.Text.ToUpper & "'")
            Dim agregar As New String("update producto set stock_cajas=stock_cajas + '" & txtdevuelto.Text.ToUpper & "' where codigo_prod='" & txtcod_prod.Text.ToUpper & "'")
            Dim comando As New SqlCommand(modificar, conectar)
            Dim comando2 As New SqlCommand(agregar, conectar)
            comando.ExecuteNonQuery()
            comando2.ExecuteNonQuery()
            lbl2.Text = "El producto ha sido modificado correctamente"
            deshabilitar()
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim eliminar As New String("delete from venta where id_venta='" & txtcodigo.Text.ToUpper & "'")
            Dim comando As New SqlCommand(eliminar, conectar)
            comando.ExecuteNonQuery()
            lbl2.Text = "El producto ha sido eliminado correctamente"
            txtcliente.Enabled = False
            txtdomicilio.Enabled = False
            txtcod_prod.Enabled = False
            txtvendedor.Enabled = False
            txtcantidad.Enabled = False
            txtfechavendida.Enabled = False
            txtdevuelto.Enabled = False
            btnmodificar.Enabled = False
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub
End Class
