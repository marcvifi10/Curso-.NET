﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class modificar_producto
    Inherits System.Web.UI.Page

    Public Sub deshabilitar()
        txtcodigo.Enabled = False
        txtmarca.Enabled = False
        txtdescripcion.Enabled = False
        txtstock.Enabled = False
        txtpreciou.Enabled = False
        txtproveedor.Enabled = False
        txtfecharegistrada.Enabled = False
    End Sub

    Public Sub habilitar()
        txtcodigo.Enabled = True
        txtmarca.Enabled = True
        txtdescripcion.Enabled = True
        txtstock.Enabled = True
        txtpreciou.Enabled = True
        txtproveedor.Enabled = True
        txtfecharegistrada.Enabled = True
    End Sub

    Protected Sub btnbuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnbuscar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim buscar As New String("select * from producto where codigo_prod='" & txtcodigo.Text.ToUpper & "'")
            Dim comando As New SqlCommand(buscar, conectar)
            Dim reader As SqlDataReader
            reader = comando.ExecuteReader
            While reader.Read
                txtcodigo.Text = reader("codigo_prod")
                txtmarca.Text = reader("marca")
                txtdescripcion.Text = reader("descripcion")
                txtstock.Text = reader("stock_cajas")
                txtpreciou.Text = reader("precio_cajas")
                txtproveedor.Text = reader("proveedor")
                txtfecharegistrada.Text = reader("fecha_reg")
                habilitar()
                MsgBox("Busqueda satisfactoria", vbInformation, "Mensaje")
                lbl1.Text = ""
            End While
            reader.Close()
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnmodificar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnmodificar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim modificar As New String("update producto set marca='" & txtmarca.Text.ToUpper & "',descripcion='" & txtdescripcion.Text.ToUpper & "',stock_cajas='" & txtstock.Text.ToUpper & "',precio_cajas='" & txtpreciou.Text.ToUpper & "',proveedor='" & txtproveedor.Text.ToUpper & "',fecha_reg='" & txtfecharegistrada.Text.ToUpper & "' where codigo_prod='" & txtcodigo.Text.ToUpper & "'")
            Dim comando As New SqlCommand(modificar, conectar)
            comando.ExecuteNonQuery()
            lbl2.Text = "El producto ha sido modificado correctamente"
            deshabilitar()
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub
End Class
