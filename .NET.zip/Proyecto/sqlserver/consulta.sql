use master
	go
		create database sistema
	go
		use sistema
	go
		create table registro
		(
			id_registro integer identity,
			usuario varchar(20) primary key,
			contrase�a varchar(20) not null,
			nombre varchar(30) not null,
			apellidos varchar(30) not null,
			sexo varchar(1) not null,
			email varchar(50) not null
		)
	go
		insert into registro values('USER','123','USUARIO1','USUARIO2','M','USUARIO@HOTMAIL.COM')
		create proc sesion
		@usuario varchar(20),
		@contrase�a varchar(20)
		as
		begin
			select * from registro where usuario=@usuario and contrase�a=@contrase�a
		end
	go
		exec sesion 'USER','123'
	go
		select * from registro order by id_registro ASC

		create table producto
		(
			codigo_prod integer identity primary key,
			marca varchar(20) not null,
			descripcion varchar(20) not null,
			stock_cajas integer not null,
			precio_cajas decimal(5,2) not null,
			proveedor varchar(50) not null,
			fecha_reg date default getdate(),
			p varchar(1) default 'P'
		)
		select * from producto order by marca asc,descripcion asc,stock_cajas desc
		insert into producto values('SAYON','GALLETA MARGARITA','300','30.50','LUCHO JUAREZ','18/12/2012','P')
		insert into producto values('SAYON','GALLETA TEJANA','250','42.20','LUCHO JUAREZ','2012-11-13','P')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('SAYON','GALLETA SODA X 100','100','23.00','LUCHO JUAREZ')

		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('VICTORIA','GALLETA CASINO MENTA','100','36.00','MARIA MARIN')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('VICTORIA','GALLETA SODA V','90','19.80','MARIA MARIN')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('VICTORIA','GALLETA CHOCOBUM','80','26.50','MARIA MARIN')

		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('COSTA','BIZCOCHO CHOCMAN','100','36.50','JOSE RODRIGUEZ')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('COSTA','CA�ONAZO','90','31.00','JOSE RODRIGUEZ')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('COSTA','GUAFER NICK','80','31.50','JOSE RODRIGUEZ')

		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('PEPSICO','SHISTRIZ','120','13.50','JOSE GARCIA')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('PEPSICO','PAPITAS LEY','100','15.50','JOSE GARCIA')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('PEPSICO','PIKEOS','110','13.50','JOSE GARCIA')

		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('AMBROSOLI','CARAMELO FULL','20','26.00','ANTONY TELLO')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('AMBROSOLI','GOMITAS FRUGILEY','40','30.00','ANTONY TELLO')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('AMBROSOLI','TOFFE MENTA','50','42.50','ANTONY TELLO')

		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('NESTLE','SUBLIME CLASICO','45','35.00','LUCIA TAYPE')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('NESTLE','TRIANGULO','32','39.60','LUCIA TAYPE')
		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('NESTLE','PRINCESA','46','42.50','LUCIA TAYPE')

		insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('VICTORIA','CHOCOSODA','3','2.60','MARIA MARIN')

		SELECT * FROM producto

		create table compra
		(
			id_compra INTEGER identity primary key,
			codigo_prod integer foreign key references producto(codigo_prod),
			almacenado_cajas integer not null,
			fecha_comp date default getdate(),
			c varchar(1)DEFAULT 'C'
		)
	go
		insert into compra (codigo_prod,almacenado_cajas) values('1','25')
		insert into compra (codigo_prod,almacenado_cajas) values('6','40')
		insert into compra (codigo_prod,almacenado_cajas) values('2','60')
		insert into compra (codigo_prod,almacenado_cajas) values('15','30')
		insert into compra (codigo_prod,almacenado_cajas) values('11','25')
		insert into compra (codigo_prod,almacenado_cajas) values('9','40')
		select * from compra

		create table venta
		(
			id_venta integer identity primary key,
			cliente varchar (30) not null,
			domicilio varchar(30) not null,
			codigo_prod integer foreign key references producto(codigo_prod),
			vendedor varchar(30) not null,
			cantidad_vend integer not null,
			fecha_venta date default getdate(),
			v varchar(1) DEFAULT 'V'
		)

		insert into venta (cliente,domicilio,codigo_prod,vendedor,cantidad_vend) values('LUIS NU�EZ CASTILLA','JR. PILPA','6','CARMEN CELESTE','30')
		insert into venta (cliente,domicilio,codigo_prod,vendedor,cantidad_vend) values('LUIS NU�EZ CASTILLA','JR. PILPA','9','CARMEN CELESTE','20')
		insert into venta (cliente,domicilio,codigo_prod,vendedor,cantidad_vend) values('MARIO LOPEZ ARANA','CLL. LIMA','13','CARMEN CELESTE','25')
		select * from venta

		-- Consulta de la tabla "producto" y "ventas" en las cuales coinciden
		select id_venta,cliente,domicilio,producto.codigo_prod,marca,descripcion,vendedor,cantidad_vend,fecha_reg
		from producto inner join venta
		on producto.codigo_prod=venta.codigo_prod

		-- Consultas de la tabla "productos" de la primera colum a la tabla "venta"
		select producto.codigo_prod as codigo,
		marca,descripcion,stock_cajas,precio_cajas,vendedor,cantidad_vend
		from producto left join venta
		on producto.codigo_prod=venta.codigo_prod

		-- Consultas de la tabla "venta" de la primera colum. a la tabla "productos"
		select producto.codigo_prod as codigo,
		marca,descripcion,stock_cajas,precio_cajas,vendedor,cantidad_vend
		from producto right join venta
		on producto.codigo_prod=venta.codigo_prod

		-- Consultas de 3 tablas
		select producto.codigo_prod as codigo,
		marca,descripcion,stock_cajas,precio_cajas,vendedor,cantidad_vend,almacenado_cajas
		from producto inner join venta
		on producto.codigo_prod=venta.codigo_prod inner join compra
		on compra.codigo_prod=producto.codigo_prod

		create view detalle_compra
		as(
			select id_compra,producto.codigo_prod,marca,descripcion,almacenado_cajas,fecha_comp
			from producto inner join compra
			on producto.codigo_prod=compra.codigo_prod
		)
		select * from detalle_compra
		-- drop view detalle_compra

		create view detalle_venta
		as(
			select id_venta,cliente,domicilio,producto.codigo_prod,marca,descripcion,vendedor,cantidad_vend,fecha_reg
			from producto inner join venta
			on producto.codigo_prod=venta.codigo_prod
		)
		select * from detalle_venta
		select * from detalle_compra

		create view compra_venta
		as(
			select producto.codigo_prod,marca,descripcion ,stock_cajas,COMPRA.c,compra.id_compra,almacenado_cajas,fecha_comp,VENTA.V,venta.id_venta,vendedor,cantidad_vend,fecha_venta
			from producto left join venta
			on producto.codigo_prod=venta.codigo_prod left join compra
			on compra.codigo_prod=producto.codigo_prod
		)
		select * from compra_venta
		drop view compra_venta

