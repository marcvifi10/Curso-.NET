﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class actualizar
    Inherits System.Web.UI.Page

    Public Sub deshabilitar()
        txtusuario.Enabled = False
        txtcontraseña.Enabled = False
        txtnueva_contr.Enabled = False
        txtre_contr.Enabled = False
        txtnombre.Enabled = False
        txtapellidos.Enabled = False
    End Sub

    Protected Sub btnaceptar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnaceptar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim modificar As New String("update registro set contraseña='" & txtre_contr.Text.ToUpper & "',nombre='" & txtnombre.Text.ToUpper & "',apellidos='" & txtapellidos.Text.ToUpper & "' where usuario='" & txtusuario.Text.ToUpper & "'")
            Dim comando As New SqlCommand(modificar, conectar)
            comando.ExecuteNonQuery()
            lbl2.Text = "Su cuenta ha sido modificado correctamente"
            deshabilitar()
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub
End Class
