﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO 'Nos sirve para importar el Gridview

Partial Class principal
    Inherits System.Web.UI.Page

    Protected Sub btntabla_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btntabla.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            Dim mostrar As New String("select * from producto order by marca asc,descripcion asc")
            Dim comando As New SqlCommand(mostrar, conectar)
            Dim ds As New DataSet
            Dim da As New SqlDataAdapter
            Dim dv As DataView
            lblproducto.Text = "Tabla de productos almacenados"

            da.SelectCommand = comando
            conectar.Open()
            da.Fill(ds, "producto")
            dv = New DataView(ds.Tables("producto"))
            GridView1.DataSource = dv
            GridView1.DataBind()
            lbl1.Text = ""
            conectar.Close()

            btntabla.Enabled = False
            btnactualizar.Enabled = True
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btntablacompra_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btntablacompra.Click    
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            Dim mostrar2 As New String("select * from detalle_compra")
            Dim comando As New SqlCommand(mostrar2, conectar)
            Dim da As New SqlDataAdapter
            Dim dv As DataView
            Dim ds As New DataSet
            lblcompra.Text = "Tabla de mis compras"

            da.SelectCommand = comando
            conectar.Open()
            da.Fill(ds, "detalle_compra")
            dv = New DataView(ds.Tables("detalle_compra"))
            GridView2.DataSource = dv
            GridView2.DataBind()
            lbl1.Text = ""
            conectar.Close()

            btntablacompra.Enabled = False
            btnactualizar.Enabled = True
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btntablaventa_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btntablaventa.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            Dim mostrar3 As New String("select * from detalle_venta")
            Dim comando As New SqlCommand(mostrar3, conectar)
            Dim da As New SqlDataAdapter
            Dim dv As DataView
            Dim ds As New DataSet
            lblventa.Text = "Tabla de mis ventas"

            da.SelectCommand = comando
            conectar.Open()
            da.Fill(ds, "detalle_venta")
            dv = New DataView(ds.Tables("detalle_venta"))
            GridView3.DataSource = dv
            GridView3.DataBind()
            lbl1.Text = ""
            conectar.Close()

            btntablaventa.Enabled = False
            btnactualizar.Enabled = True
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnactualizar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnactualizar.Click
        Try
                btntabla_Click(Nothing, Nothing)
                btntablacompra_Click(Nothing, Nothing)
                btntablaventa_Click(Nothing, Nothing)
        Catch ex As Exception
            lbl1.Text = "Error " & ex.Message
        End Try
        
    End Sub

    'permite acceder a los datos que se van enlazando en cada fila del grid.ejm: poder cambiar el color de la fila
    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            If e.Row.Cells(3).Text <= 10 Then
                e.Row.BackColor = Drawing.Color.Red
                e.Row.ForeColor = Drawing.Color.White
            ElseIf e.Row.Cells(3).Text > 10 And e.Row.Cells(3).Text <= 30 Then
                e.Row.BackColor = Drawing.Color.Yellow
            End If
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblfecha.Text = (Now().Date.ToLongDateString)
    End Sub
End Class
