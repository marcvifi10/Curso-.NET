﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class producto
    Inherits System.Web.UI.Page

    Protected Sub btnregistrar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnregistrar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim insertar As New String("Insert into producto (marca,descripcion,stock_cajas,precio_cajas,proveedor) values('" & txtmarca.Text.ToUpper & "','" & txtdescripcion.Text.ToUpper & "','" & txtstock.Text.ToUpper & "','" & txtpreciou.Text.ToUpper & "','" & txtproveedor.Text.ToUpper & "')")
            Dim comando As New SqlCommand(insertar, conectar)
            comando.ExecuteNonQuery()
            lbl3.Text = "El producto ha sido registrado correctamente"
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub
End Class
