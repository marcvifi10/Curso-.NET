﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class eliminar
    Inherits System.Web.UI.Page

    Protected Sub btneliminar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btneliminar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim eliminar As New String("delete from producto where codigo_prod='" & txtcodigo.Text.ToUpper & "'")
            Dim comando As New SqlCommand(eliminar, conectar)
            comando.ExecuteNonQuery()
            lbl2.Text = "El producto ha sido eliminado correctamente"
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub

    Protected Sub btnbuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnbuscar.Click
        Try
            Dim conectar As New SqlConnection("Data Source=(local)\SQLEXPRESS;Initial Catalog=sistema;Integrated Security=True")
            conectar.Open()
            Dim buscar As New String("select * from producto where codigo_prod='" & txtcodigo.Text.ToUpper & "'")
            Dim comando As New SqlCommand(buscar, conectar)
            Dim reader As SqlDataReader
            reader = comando.ExecuteReader
            While reader.Read
                txtcodigo.Text = reader("codigo_prod")
                txtmarca.Text = reader("marca")
                txtdescripcion.Text = reader("descripcion")
                txtstock.Text = reader("stock_cajas")
                txtpreciou.Text = reader("precio_cajas")
                txtproveedor.Text = reader("proveedor")
                txtfecharegistrada.Text = reader("fecha_reg")
                MsgBox("Busqueda satisfactoria", vbInformation, "Mensaje")
                lbl1.Text = ""
            End While
            reader.Close()
            conectar.Close()
        Catch ex As Exception
            lbl1.Text = ex.Message
        End Try
    End Sub
End Class
